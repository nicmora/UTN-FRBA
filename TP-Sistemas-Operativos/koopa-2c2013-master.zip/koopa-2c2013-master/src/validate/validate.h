#ifndef VALIDATE_H_
#define VALIDATE_H_

	#include "../headers.h"

	void validate_terminalSize();
	void validate_paths(char** argv);

#endif
