#ifndef MAIN_HEADERS_H_
#define MAIN_HEADERS_H_

	#include "anim/koopa/koopa.h"
	#include "files/files.h"
	#include "validate/validate.h"
	#include "magic/magic.h"

	bool win;
	char* dumpGrasa;

#endif
