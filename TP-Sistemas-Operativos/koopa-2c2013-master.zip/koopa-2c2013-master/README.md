![bowser](https://f.cloud.github.com/assets/1631752/1443053/67c9282a-41d3-11e3-8977-109001218acb.jpg)

Ver https://github.com/sisoputnfrba/koopa-2c2013/wiki/Koopa
